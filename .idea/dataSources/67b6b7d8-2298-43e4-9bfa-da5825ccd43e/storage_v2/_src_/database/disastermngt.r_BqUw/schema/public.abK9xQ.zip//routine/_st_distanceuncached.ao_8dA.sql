create function _st_distanceuncached(geography, geography) returns double precision
    immutable
    strict
    language sql
as
$$
SELECT public._ST_DistanceUnCached($1, $2, 0.0, true)
$$;

alter function _st_distanceuncached(geography, geography) owner to postgres;

