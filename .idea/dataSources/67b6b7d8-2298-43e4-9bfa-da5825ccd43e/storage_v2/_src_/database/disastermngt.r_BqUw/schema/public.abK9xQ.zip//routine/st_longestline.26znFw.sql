create function st_longestline(geom1 geometry, geom2 geometry) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public._ST_LongestLine(public.ST_ConvexHull($1), public.ST_ConvexHull($2))
$$;

comment on function st_longestline(geometry, geometry) is 'args: g1, g2 - Returns the 2-dimensional longest line points of two geometries. The function will only return the first longest line if more than one, that the function finds. The line returned will always start in g1 and end in g2. The length of the line this function returns will always be the same as st_maxdistance returns for g1 and g2.';

alter function st_longestline(geometry, geometry) owner to postgres;

